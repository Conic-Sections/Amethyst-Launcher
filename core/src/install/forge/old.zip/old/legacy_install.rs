use anyhow::Result;
use tokio::fs::{self, create_dir_all};

use crate::{folder::MinecraftLocation, version::LibraryInfo, DATA_LOCATION};

use super::{install_profile::InstallProfileLegacy, *};

pub(super) async fn install_legacy_forge_from_zip(
    entries: ForgeLegacyInstallerEntriesPatten,
    profile: InstallProfileLegacy,
    minecraft: MinecraftLocation,
    options: Option<InstallForgeOptions>,
) -> Result<()> {
    let options = match options {
        Some(options) => options,
        None => InstallForgeOptions {
            maven_host: None,
            inherits_from: None,
            version_id: None,
            java: Some(DATA_LOCATION.get().unwrap().default_jre.clone()),
        },
    };
    let mut version_json = profile.version_info.clone().unwrap();

    // apply override for inheritsFrom
    version_json.id = options.version_id.unwrap_or(version_json.id);
    version_json.inherits_from = match options.inherits_from {
        None => version_json.inherits_from,
        Some(inherits_from) => Some(inherits_from),
    };

    let root_path = minecraft.get_version_root(&version_json.id);
    let version_json_path = root_path.join(format!("{}.json", version_json.id));
    let install_profile_path = root_path.join("install_profile.json");
    create_dir_all(&version_json_path.parent().unwrap()).await?;
    let library = version_json.libraries.clone().unwrap();
    let library = library
        .iter()
        .find(|l| {
            l["name"]
                .as_str()
                .unwrap()
                .starts_with("net.minecraftforge:forge")
        })
        .unwrap();
    let library = LibraryInfo::from_value(library);

    fs::write(
        version_json_path,
        serde_json::to_string_pretty(&version_json)?,
    )
    .await?;
    fs::write(
        install_profile_path,
        serde_json::to_string_pretty(&profile)?,
    )
    .await?;

    create_dir_all(
        minecraft
            .get_library_by_path(&library.path)
            .parent()
            .unwrap(),
    )
    .await?;
    fs::write(
        minecraft.get_library_by_path(&library.path),
        entries.legacy_universal_jar.content,
    )
    .await?;

    Ok(())
}
